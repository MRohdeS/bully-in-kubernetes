from flask import Flask 

app = Flask(__name__)

@app.route("/")
@app.route('/index')
def hello_world():
    return "<h2>Hello world!<h2>"

@app.route('/ligma')
def ligma():
    return "Ligma balls"

app.run(host='0.0.0.0', debug=True)